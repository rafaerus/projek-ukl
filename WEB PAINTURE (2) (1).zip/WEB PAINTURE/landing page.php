<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
     <link rel="stylesheet" type="text/css" href="tugas akhir.css" />
    <title>Painture</title>
  </head>
  <body>
  <div class="Fcontainer">
    <nav class="navbar">
      <a href="landing page.php">halaman utama</a>
      <a href="layanan.php">layanan</a>
      <a href="pesanan.php">pemesanan</a>
      <a href="tentang kami.php">tentang kami</a>
      <a href="register.php">register</a>
      <a href="halaman login.php">login</a>
    </nav>
    </div>
    <div class="judul"><h1>Painture</h1></div>

    <div class="container">
      <div class="content">
        <h1>painture adalah jasa ilustrasi dan toko fan art</h1>
      </div>
      <br />
      <h3 style="color: white; font-size: 20px; text-align: center">
        Berikut adalah beberapa contoh ilustrasi yang telah kami buat tanpa
        referensi
      </h3>

      <div
        style="border: 1px solid #ffffff; border-radius: 40px 40px 40px 40px"
        class="img1"
      >
        <h2>Gambar Ilustrasi</h2>
        <img
          style="border: 1px solid #ffffff; border-radius: 40px 40px 40px 40px"
          src="violet pose.jpg"
          alt="Ilustrasi 1"
          height="400px"
          width="360px"
        />
      </div>

      <div
        style="border: 1px solid #ffffff; border-radius: 40px 40px 40px 40px"
        class="img2"
      >
        <h2>Gambar Ilustrasi</h2>
        <img
          style="border: 1px solid #ffffff; border-radius: 40px 40px 40px 40px"
          src="violet cry.jpg"
          alt="Ilustrasi 2"
          height="400px"
          width="360px"
        />
      </div>

      <div class="content">
        <h2>Tertarik dengan jasa Kami?</h2>
        <h2>cari tahu lebih lanjut di <a href="layanan.php">layanan</a> dan <a href="tentang kami.php">tentang kami!</a></h2>
      </div>
    </div>

    <div class="footer">
      <p>&copy; 2023 Painture. All rights reserved.</p>
    </div>
  </body>
</html>
