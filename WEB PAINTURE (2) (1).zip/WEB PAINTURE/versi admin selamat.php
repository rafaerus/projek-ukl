<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesanan Berhasil Dibuat</title>
</head>
<body>
    <link rel="stylesheet" href="selamat.css"/>
    <div class="container">
        <h1>Selamat! Pesanan Anda Berhasil Dibuat</h1>
        <p>Pesanan Anda akan segera dikerjakan dan kami akan segera memberitahukan Anda melalui email.</p>
        <a href="versi admin landing page.php" class="btn">Lanjut ke Halaman Utama</a>
    
    </div>
</body>
</html>
