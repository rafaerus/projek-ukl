<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tentang Kami</title>
  </head>
  <body>
    <link rel="stylesheet" href="tugas akhir.css" />
    <div class="Fcontainer">
    <nav class="navbar">
      <a href="landing page.php">halaman utama</a>
      <a href="layanan.php">layanan</a>
      <a href="pesanan.php">pemesanan</a>
      <a href="tentang kami.php">tentang kami</a>
      <a href="register.php">register</a>
      <a href="halaman login.php">login</a>
    </nav>
    </div>


    <div 
    style="border: 1px solid #ffffff; border-radius: 40px 40px 40px 40px"
    class="profil">
      <h1 style="font-size: 60px;font-family: 'Times New Roman', Times, serif;font-style: italic;">profil</h1>
    <img src="foto profil.jpg" alt="img"
    width="200px"
    height="260px"
    style="border: 1px solid #ffffff; border-radius: 40px 40px 40px 40px"
    >
    <p style="text-align: left;font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; font-size: large;" >
    nama : rafael bonnie matien sasmito
    <br>
    umur : 16 tahun
    <br>
    agama : islam
    <br>
    alamat : sekardangan indah
    <br>
    status : pelajar
    </p>
    </div>
    <br>
    <br>
    <br>

    <div class="icon" style="display: inline-flex; text-align: center;">
    <div style="padding-right: 20px; display: inline-flex;" >
      <img src="telepon_icon-removebg-preview.png" alt="telepon" width="60px" height="60px" >
      <h2 style="padding-left: 10px;">0821-2525-5106</h2>
    </div>
    
    <div style="display: inline-flex;">
      <img src="email_icon-removebg-preview.png" alt="email" width="75px" height="60px">
      <h2 style="padding-left: 10px;">rafael.bonnie2018@gmail.com</h2>
    </div>
  </div>


    <div class="footer">
      <p>&copy; 2023 Painture. All rights reserved.</p>
    </div>
  </body>
  </body>
</html>

